<section class="hero" id="hero">
      <div class="hero-watermark left" aria-hidden="true"></div>
      <div class="hero-watermark right" aria-hidden="true"></div>
      <div class="hero-watermark extra near-phone-1" aria-hidden="true"></div>
      <div class="hero-watermark extra near-phone-2" aria-hidden="true"></div>
      <div class="hero-watermark extra near-phone-3" aria-hidden="true"></div>
      <div class="container hero-grid">
        <div class="hero-copy reveal">
          <span class="eyebrow">Coparentes</span>
          <h1>分开后也能平静共同育儿</h1>
          <p>在两个家庭之间共同安排孩子的生活，没有压力，也少一些冲突。一切都在一个简单的应用中完成。</p>
          <div class="hero-actions">
            <a href="#download" class="btn btn-primary btn-large">免费开始安排</a>
            <div class="store-row">
              <a href="#download" class="store-logo-link" aria-label="在 App Store 下载">
                <img class="store-logo-image" src="<?php echo esc_url( get_template_directory_uri() . '/assets/store/app-store-logo.svg' ); ?>" alt="" aria-hidden="true" />
              </a>
              <a href="#download" class="store-logo-link" aria-label="在 Google Play 获取">
                <img class="store-logo-image" src="<?php echo esc_url( get_template_directory_uri() . '/assets/store/google-play-logo.svg' ); ?>" alt="" aria-hidden="true" />
              </a>
            </div>
          </div>
        </div>

        <div class="hero-visual reveal delay-1">
          <div class="hero-visual-watermark top-left" aria-hidden="true"></div>
          <div class="hero-visual-watermark top-right" aria-hidden="true"></div>
          <div class="hero-visual-watermark mid-right" aria-hidden="true"></div>
          <div class="hero-visual-watermark bottom-right" aria-hidden="true"></div>
          <img class="hero-phones-image" src="<?php echo esc_url( get_template_directory_uri() . '/assets/illustrations/hero-phones-zh.png' ); ?>" alt="" />
        </div>
      </div>
    </section>

    <section class="section benefits" id="benefits">
      <div class="container section-title reveal">
        <h2>共同照顾孩子可以更轻松</h2>
      </div>
      <div class="container cards cards-3"><article class="soft-card benefit-card reveal">
          <div class="circle-icon blue-soft"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/icons/comments.svg' ); ?>" alt="" aria-hidden="true" /></div>
          <h3>沟通</h3>
          <p>安全聊天和历史记录，减少误解。</p>
        </article><article class="soft-card benefit-card reveal delay-1">
          <div class="circle-icon green-soft"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/icons/calendar-days.svg' ); ?>" alt="" aria-hidden="true" /></div>
          <h3>安排</h3>
          <p>共享日历和照护计划随时可看。</p>
        </article><article class="soft-card benefit-card reveal delay-2">
          <div class="circle-icon coral-soft"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/icons/wallet.svg' ); ?>" alt="" aria-hidden="true" /></div>
          <h3>财务</h3>
          <p>与孩子相关的费用记录清晰透明。</p>
        </article></div>
    </section>

    <section class="section features" id="features">
      <div class="container section-title reveal">
        <h2>你需要的一切<br />都在一个地方</h2>
      </div>
      <div class="container feature-grid"><article class="feature-card reveal border-teal">
          <div class="feature-icon teal-bg"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/icons/calendar-check.svg' ); ?>" alt="" aria-hidden="true" /></div>
          <h3>共享日历</h3>
          <p>安排约诊、假期、学校和活动，不再发生时间冲突。</p>
        </article><article class="feature-card reveal delay-1 border-blue">
          <div class="feature-icon blue-bg"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/icons/comment-dots.svg' ); ?>" alt="" aria-hidden="true" /></div>
          <h3>安全聊天</h3>
          <p>把关于孩子的沟通集中在一个有序空间里。</p>
        </article><article class="feature-card reveal delay-2 border-coral">
          <div class="feature-icon coral-bg"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/icons/receipt.svg' ); ?>" alt="" aria-hidden="true" /></div>
          <h3>费用记录</h3>
          <p>上传票据，轻松分摊与养育相关的花费。</p>
        </article><article class="feature-card reveal border-yellow">
          <div class="feature-icon yellow-bg"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/icons/folder-open.svg' ); ?>" alt="" aria-hidden="true" /></div>
          <h3>孩子资料</h3>
          <p>保存重要文件、备注、证明和体检时间。</p>
        </article><article class="feature-card reveal delay-1 border-purple">
          <div class="feature-icon purple-bg"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/icons/house-user.svg' ); ?>" alt="" aria-hidden="true" /></div>
          <h3>照护安排</h3>
          <p>设定照护计划，快速查看哪一天由谁负责。</p>
        </article><article class="feature-card reveal delay-2 border-teal">
          <div class="feature-icon teal-bg"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/icons/bell.svg' ); ?>" alt="" aria-hidden="true" /></div>
          <h3>通知提醒</h3>
          <p>及时收到重要事件、付款和变更提醒。</p>
        </article></div>
    </section>

    <section class="section how-it-works" id="how-it-works">
      <div class="container how-grid">
        <div class="how-copy reveal">
          <h2>Coparentes 如何运作？</h2>
          <div class="step-list"><article class="step-item">
              <span class="step-number teal-text">1</span>
              <div>
                <h3>创建账户并邀请另一位家长</h3>
                <p>快速开始，让协作从一开始就更清晰。</p>
              </div>
            </article><article class="step-item">
              <span class="step-number blue-text">2</span>
              <div>
                <h3>设置孩子档案</h3>
                <p>填写孩子信息、日程和重要资料。</p>
              </div>
            </article><article class="step-item">
              <span class="step-number coral-text">3</span>
              <div>
                <h3>使用组织工具</h3>
                <p>聊天、日历、费用和文件协同工作。</p>
              </div>
            </article><article class="step-item">
              <span class="step-number yellow-text">4</span>
              <div>
                <h3>享受更平静的育儿协作</h3>
                <p>更少混乱，更多清晰，为孩子带来更好的合作体验。</p>
              </div>
            </article></div>
        </div>

        <div class="how-visual reveal delay-1">
          <img class="how-phone-image" src="<?php echo esc_url( get_template_directory_uri() . '/assets/illustrations/how-it-works-phone-pl.png' ); ?>" alt="" />
          <div class="family-card">
            <div class="family-avatars"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/illustrations/family-avatars.svg' ); ?>" alt="" aria-hidden="true" /></div>
            <p>当一切都在同一个地方时，合作会更容易。</p>
          </div>
        </div>
      </div>
    </section>

    <section class="section follow-up" id="follow-up">
      <div class="container follow-up-grid">
        <div class="follow-up-copy reveal">
          <span class="eyebrow">Follow-up</span>
          <h2>不错过每一个下一步</h2>
          <p>在一次沟通、日历变更或新增费用之后，Coparentes 帮助把约定变成具体行动。</p>
        </div>
        <div class="follow-up-list">
          <article class="follow-up-card reveal delay-1">
            <div class="feature-icon blue-bg"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/icons/comment-dots.svg' ); ?>" alt="" aria-hidden="true" /></div>
            <div>
              <h3>对话跟进</h3>
              <p>把消息标记为任务，在需要决定或回复时快速回到上下文。</p>
            </div>
          </article>
          <article class="follow-up-card reveal delay-2">
            <div class="feature-icon teal-bg"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/icons/calendar-check.svg' ); ?>" alt="" aria-hidden="true" /></div>
            <div>
              <h3>期限提醒</h3>
              <p>为接送、约诊或付款添加跟进，让双方家长都知道下一步是什么。</p>
            </div>
          </article>
          <article class="follow-up-card reveal delay-1">
            <div class="feature-icon coral-bg"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/icons/bell.svg' ); ?>" alt="" aria-hidden="true" /></div>
            <div>
              <h3>平静收尾</h3>
              <p>完成后标记状态，减少额外追问和误解。</p>
            </div>
          </article>
        </div>
      </div>
    </section>

    <section class="section audience" id="audience">
      <div class="container section-title reveal">
        <h2>Coparentes 适合谁？</h2>
      </div>
      <div class="container cards cards-4"><article class="soft-card audience-card reveal">
          <img class="house-illustration" src="<?php echo esc_url( get_template_directory_uri() . '/assets/illustrations/audience-mom.svg' ); ?>" alt="" aria-hidden="true" />
          <h3>适合妈妈</h3>
          <p>更从容地掌握孩子的时间安排。</p>
        </article><article class="soft-card audience-card reveal delay-1">
          <img class="house-illustration" src="<?php echo esc_url( get_template_directory_uri() . '/assets/illustrations/audience-dad.svg' ); ?>" alt="" aria-hidden="true" />
          <h3>适合爸爸</h3>
          <p>随时了解孩子生活中的重要信息。</p>
        </article><article class="soft-card audience-card reveal delay-2">
          <img class="house-illustration" src="<?php echo esc_url( get_template_directory_uri() . '/assets/illustrations/audience-child.svg' ); ?>" alt="" aria-hidden="true" />
          <h3>适合孩子</h3>
          <p>更可预测，就更安心。</p>
        </article><article class="soft-card audience-card reveal delay-3">
          <img class="house-illustration" src="<?php echo esc_url( get_template_directory_uri() . '/assets/illustrations/audience-family.svg' ); ?>" alt="" aria-hidden="true" />
          <h3>适合整个家庭</h3>
          <p>为了孩子而进行的共同组织与协作。</p>
        </article></div>
    </section>

    <section class="section testimonials" id="testimonials">
      <div class="container section-title reveal">
        <h2>家长们怎么说？</h2>
      </div>
      <div class="container cards cards-3"><article class="soft-card testimonial-card reveal">
          <img class="person-avatar" src="<?php echo esc_url( get_template_directory_uri() . '/assets/illustrations/avatar-anna.svg' ); ?>" alt="Ewa" />
          <div class="stars"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/icons/stars-rating.svg' ); ?>" alt="5/5" /></div>
          <blockquote>“如果在我离婚时就有这样的应用，我的生活会轻松很多。”</blockquote>
          <p class="person-name">Ewa</p>
        </article><article class="soft-card testimonial-card reveal delay-1">
          <img class="person-avatar" src="<?php echo esc_url( get_template_directory_uri() . '/assets/illustrations/avatar-marek.svg' ); ?>" alt="Andrzej" />
          <div class="stars"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/icons/stars-rating.svg' ); ?>" alt="5/5" /></div>
          <blockquote>“我不喜欢同时用很多应用，但很愿意试试这个，因为我感觉它真的能让我生活更轻松。”</blockquote>
          <p class="person-name">Andrzej</p>
        </article><article class="soft-card testimonial-card reveal delay-2">
          <img class="person-avatar" src="<?php echo esc_url( get_template_directory_uri() . '/assets/illustrations/avatar-kasia.svg' ); ?>" alt="Agnieszka" />
          <div class="stars"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/icons/stars-rating.svg' ); ?>" alt="5/5" /></div>
          <blockquote>“我相信有了 Coparentes，记录孩子的开支会更容易。”</blockquote>
          <p class="person-name">Agnieszka</p>
        </article></div>
    </section>

    <section class="cta-section" id="download">
      <div class="cta-watermark left" aria-hidden="true"></div>
      <div class="cta-watermark right" aria-hidden="true"></div>
      <div class="container cta-content reveal">
        <h2>现在开始<br />更平静地安排生活</h2>
        <a href="#" class="btn btn-white btn-large">免费下载</a>
        <div class="store-row center cta-store-row">
          <a href="#" class="store-badge light" aria-label="App Store">
            <img class="store-badge-icon" src="<?php echo esc_url( get_template_directory_uri() . '/assets/icons/apple.svg' ); ?>" alt="" aria-hidden="true" />
            <span><small>下载于</small><strong>App Store</strong></span>
          </a>
          <a href="#" class="store-badge light" aria-label="Google Play">
            <img class="store-badge-icon" src="<?php echo esc_url( get_template_directory_uri() . '/assets/icons/google-play.svg' ); ?>" alt="" aria-hidden="true" />
            <span><small>获取于</small><strong>Google Play</strong></span>
          </a>
        </div>
        <p>免费。无需承诺。</p>
      </div>
    </section>
