<section class="hero" id="hero">
      <div class="hero-watermark left" aria-hidden="true"></div>
      <div class="hero-watermark right" aria-hidden="true"></div>
      <div class="hero-watermark extra near-phone-1" aria-hidden="true"></div>
      <div class="hero-watermark extra near-phone-2" aria-hidden="true"></div>
      <div class="hero-watermark extra near-phone-3" aria-hidden="true"></div>
      <div class="container hero-grid">
        <div class="hero-copy reveal">
          <span class="eyebrow">Coparentes</span>
          <h1>Coparentalité sereine après la séparation</h1>
          <p>L’organisation partagée de la vie de votre enfant entre deux foyers, sans stress ni conflit. Tout dans une seule application simple.</p>
          <div class="hero-actions">
            <a href="#download" class="btn btn-primary btn-large">Commencer gratuitement</a>
            <div class="store-row">
              <a href="#download" class="store-logo-link" aria-label="Télécharger sur App Store">
                <img class="store-logo-image" src="<?php echo esc_url( get_template_directory_uri() . '/assets/store/app-store-logo.svg' ); ?>" alt="" aria-hidden="true" />
              </a>
              <a href="#download" class="store-logo-link" aria-label="Disponible sur Google Play">
                <img class="store-logo-image" src="<?php echo esc_url( get_template_directory_uri() . '/assets/store/google-play-logo.svg' ); ?>" alt="" aria-hidden="true" />
              </a>
            </div>
          </div>
        </div>

        <div class="hero-visual reveal delay-1">
          <div class="hero-visual-watermark top-left" aria-hidden="true"></div>
          <div class="hero-visual-watermark top-right" aria-hidden="true"></div>
          <div class="hero-visual-watermark mid-right" aria-hidden="true"></div>
          <div class="hero-visual-watermark bottom-right" aria-hidden="true"></div>
          <img class="hero-phones-image" src="<?php echo esc_url( get_template_directory_uri() . '/assets/illustrations/hero-phones-fr.png' ); ?>" alt="" />
        </div>
      </div>
    </section>

    <section class="section benefits" id="benefits">
      <div class="container section-title reveal">
        <h2>La garde partagée des enfants peut être plus simple</h2>
      </div>
      <div class="container cards cards-3"><article class="soft-card benefit-card reveal">
          <div class="circle-icon blue-soft"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/icons/comments.svg' ); ?>" alt="" aria-hidden="true" /></div>
          <h3>Communication</h3>
          <p>Chat sécurisé et historique des échanges pour éviter les malentendus.</p>
        </article><article class="soft-card benefit-card reveal delay-1">
          <div class="circle-icon green-soft"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/icons/calendar-days.svg' ); ?>" alt="" aria-hidden="true" /></div>
          <h3>Organisation</h3>
          <p>Calendrier partagé et planning de garde toujours à portée de main.</p>
        </article><article class="soft-card benefit-card reveal delay-2">
          <div class="circle-icon coral-soft"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/icons/wallet.svg' ); ?>" alt="" aria-hidden="true" /></div>
          <h3>Finances</h3>
          <p>Suivi clair et transparent des dépenses liées à votre enfant.</p>
        </article></div>
    </section>

    <section class="section features" id="features">
      <div class="container section-title reveal">
        <h2>Tout ce dont vous avez besoin<br />au même endroit</h2>
      </div>
      <div class="container feature-grid"><article class="feature-card reveal border-teal">
          <div class="feature-icon teal-bg"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/icons/calendar-check.svg' ); ?>" alt="" aria-hidden="true" /></div>
          <h3>Calendrier partagé</h3>
          <p>Planifiez rendez-vous, vacances, école et événements sans conflit de dates.</p>
        </article><article class="feature-card reveal delay-1 border-blue">
          <div class="feature-icon blue-bg"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/icons/comment-dots.svg' ); ?>" alt="" aria-hidden="true" /></div>
          <h3>Chat sécurisé</h3>
          <p>Parlez uniquement de votre enfant dans un espace organisé.</p>
        </article><article class="feature-card reveal delay-2 border-coral">
          <div class="feature-icon coral-bg"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/icons/receipt.svg' ); ?>" alt="" aria-hidden="true" /></div>
          <h3>Suivi des dépenses</h3>
          <p>Ajoutez des reçus et répartissez facilement les coûts liés à l’éducation.</p>
        </article><article class="feature-card reveal border-yellow">
          <div class="feature-icon yellow-bg"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/icons/folder-open.svg' ); ?>" alt="" aria-hidden="true" /></div>
          <h3>Documents de l’enfant</h3>
          <p>Conservez fichiers, notes, certificats et dates importantes.</p>
        </article><article class="feature-card reveal delay-1 border-purple">
          <div class="feature-icon purple-bg"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/icons/house-user.svg' ); ?>" alt="" aria-hidden="true" /></div>
          <h3>Planning de garde</h3>
          <p>Définissez la garde et vérifiez rapidement qui s’occupe de quel jour.</p>
        </article><article class="feature-card reveal delay-2 border-teal">
          <div class="feature-icon teal-bg"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/icons/bell.svg' ); ?>" alt="" aria-hidden="true" /></div>
          <h3>Notifications</h3>
          <p>Recevez des rappels sur les événements, paiements et changements importants.</p>
        </article></div>
    </section>

    <section class="section how-it-works" id="how-it-works">
      <div class="container how-grid">
        <div class="how-copy reveal">
          <h2>Comment fonctionne Coparentes ?</h2>
          <div class="step-list"><article class="step-item">
              <span class="step-number teal-text">1</span>
              <div>
                <h3>Créez un compte et invitez l’autre parent</h3>
                <p>Un démarrage rapide et une collaboration claire dès le départ.</p>
              </div>
            </article><article class="step-item">
              <span class="step-number blue-text">2</span>
              <div>
                <h3>Configurez le profil de l’enfant</h3>
                <p>Ajoutez les informations, le planning et les données essentielles.</p>
              </div>
            </article><article class="step-item">
              <span class="step-number coral-text">3</span>
              <div>
                <h3>Utilisez les outils d’organisation</h3>
                <p>Chat, calendrier, dépenses et documents fonctionnent ensemble.</p>
              </div>
            </article><article class="step-item">
              <span class="step-number yellow-text">4</span>
              <div>
                <h3>Profitez d’une parentalité plus sereine</h3>
                <p>Moins de chaos, plus de clarté et une meilleure coopération pour votre enfant.</p>
              </div>
            </article></div>
        </div>

        <div class="how-visual reveal delay-1">
          <img class="how-phone-image" src="<?php echo esc_url( get_template_directory_uri() . '/assets/illustrations/how-it-works-phone-pl.png' ); ?>" alt="" />
          <div class="family-card">
            <div class="family-avatars"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/illustrations/family-avatars.svg' ); ?>" alt="" aria-hidden="true" /></div>
            <p>Il est plus facile de coopérer quand tout est au même endroit.</p>
          </div>
        </div>
      </div>
    </section>

    <section class="section follow-up" id="follow-up">
      <div class="container follow-up-grid">
        <div class="follow-up-copy reveal">
          <span class="eyebrow">Follow-up</span>
          <h2>Ne perdez jamais la prochaine étape</h2>
          <p>Après une conversation, un changement de calendrier ou une nouvelle dépense, Coparentes aide à transformer les accords en actions concrètes.</p>
        </div>
        <div class="follow-up-list">
          <article class="follow-up-card reveal delay-1">
            <div class="feature-icon blue-bg"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/icons/comment-dots.svg' ); ?>" alt="" aria-hidden="true" /></div>
            <div>
              <h3>Suivi des conversations</h3>
              <p>Marquez un message comme tâche et revenez-y lorsqu’une décision ou une réponse est nécessaire.</p>
            </div>
          </article>
          <article class="follow-up-card reveal delay-2">
            <div class="feature-icon teal-bg"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/icons/calendar-check.svg' ); ?>" alt="" aria-hidden="true" /></div>
            <div>
              <h3>Rappels d’échéance</h3>
              <p>Ajoutez un suivi pour les récupérations, rendez-vous ou paiements afin que chaque parent sache quoi faire ensuite.</p>
            </div>
          </article>
          <article class="follow-up-card reveal delay-1">
            <div class="feature-icon coral-bg"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/icons/bell.svg' ); ?>" alt="" aria-hidden="true" /></div>
            <div>
              <h3>Clôture sereine</h3>
              <p>Indiquez les tâches terminées pour éviter les questions supplémentaires et les malentendus.</p>
            </div>
          </article>
        </div>
      </div>
    </section>

    <section class="section audience" id="audience">
      <div class="container section-title reveal">
        <h2>À qui s’adresse Coparentes ?</h2>
      </div>
      <div class="container cards cards-4"><article class="soft-card audience-card reveal">
          <img class="house-illustration" src="<?php echo esc_url( get_template_directory_uri() . '/assets/illustrations/audience-mom.svg' ); ?>" alt="" aria-hidden="true" />
          <h3>Pour maman</h3>
          <p>Gardez votre calme et le contrôle sur le planning de votre enfant.</p>
        </article><article class="soft-card audience-card reveal delay-1">
          <img class="house-illustration" src="<?php echo esc_url( get_template_directory_uri() . '/assets/illustrations/audience-dad.svg' ); ?>" alt="" aria-hidden="true" />
          <h3>Pour papa</h3>
          <p>Restez toujours au courant de la vie de votre enfant.</p>
        </article><article class="soft-card audience-card reveal delay-2">
          <img class="house-illustration" src="<?php echo esc_url( get_template_directory_uri() . '/assets/illustrations/audience-child.svg' ); ?>" alt="" aria-hidden="true" />
          <h3>Pour l’enfant</h3>
          <p>Plus de prévisibilité, c’est plus de sérénité.</p>
        </article><article class="soft-card audience-card reveal delay-3">
          <img class="house-illustration" src="<?php echo esc_url( get_template_directory_uri() . '/assets/illustrations/audience-family.svg' ); ?>" alt="" aria-hidden="true" />
          <h3>Pour toute la famille</h3>
          <p>Une organisation partagée pour le bien de l’enfant.</p>
        </article></div>
    </section>

    <section class="section testimonials" id="testimonials">
      <div class="container section-title reveal">
        <h2>Que disent les parents ?</h2>
      </div>
      <div class="container cards cards-3"><article class="soft-card testimonial-card reveal">
          <img class="person-avatar" src="<?php echo esc_url( get_template_directory_uri() . '/assets/illustrations/avatar-anna.svg' ); ?>" alt="Ewa" />
          <div class="stars"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/icons/stars-rating.svg' ); ?>" alt="5/5" /></div>
          <blockquote>« Ma vie aurait été plus facile si une application comme celle-ci avait existé au moment de mon divorce. »</blockquote>
          <p class="person-name">Ewa</p>
        </article><article class="soft-card testimonial-card reveal delay-1">
          <img class="person-avatar" src="<?php echo esc_url( get_template_directory_uri() . '/assets/illustrations/avatar-marek.svg' ); ?>" alt="Andrzej" />
          <div class="stars"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/icons/stars-rating.svg' ); ?>" alt="5/5" /></div>
          <blockquote>« Je n’aime pas utiliser beaucoup d’applications, mais je veux volontiers essayer celle-ci car je sens qu’elle peut vraiment me simplifier la vie. »</blockquote>
          <p class="person-name">Andrzej</p>
        </article><article class="soft-card testimonial-card reveal delay-2">
          <img class="person-avatar" src="<?php echo esc_url( get_template_directory_uri() . '/assets/illustrations/avatar-kasia.svg' ); ?>" alt="Agnieszka" />
          <div class="stars"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/icons/stars-rating.svg' ); ?>" alt="5/5" /></div>
          <blockquote>« Je suis convaincue qu’avec Coparentes, il me sera plus facile de documenter les dépenses pour les enfants. »</blockquote>
          <p class="person-name">Agnieszka</p>
        </article></div>
    </section>

    <section class="cta-section" id="download">
      <div class="cta-watermark left" aria-hidden="true"></div>
      <div class="cta-watermark right" aria-hidden="true"></div>
      <div class="container cta-content reveal">
        <h2>Commencez à organiser<br />la vie plus sereinement</h2>
        <a href="#" class="btn btn-white btn-large">Télécharger gratuitement</a>
        <div class="store-row center cta-store-row">
          <a href="#" class="store-badge light" aria-label="App Store">
            <img class="store-badge-icon" src="<?php echo esc_url( get_template_directory_uri() . '/assets/icons/apple.svg' ); ?>" alt="" aria-hidden="true" />
            <span><small>Télécharger sur</small><strong>App Store</strong></span>
          </a>
          <a href="#" class="store-badge light" aria-label="Google Play">
            <img class="store-badge-icon" src="<?php echo esc_url( get_template_directory_uri() . '/assets/icons/google-play.svg' ); ?>" alt="" aria-hidden="true" />
            <span><small>Disponible sur</small><strong>Google Play</strong></span>
          </a>
        </div>
        <p>Gratuit. Sans engagement.</p>
      </div>
    </section>
