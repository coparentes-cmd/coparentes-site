<section class="hero" id="hero">
      <div class="hero-watermark left" aria-hidden="true"></div>
      <div class="hero-watermark right" aria-hidden="true"></div>
      <div class="hero-watermark extra near-phone-1" aria-hidden="true"></div>
      <div class="hero-watermark extra near-phone-2" aria-hidden="true"></div>
      <div class="hero-watermark extra near-phone-3" aria-hidden="true"></div>
      <div class="container hero-grid">
        <div class="hero-copy reveal">
          <span class="eyebrow">Coparentes</span>
          <h1>Calm co-parenting after separation</h1>
          <p>Shared organization of your child’s life across two homes, without stress or conflict. Everything in one simple app.</p>
          <div class="hero-actions">
            <a href="#download" class="btn btn-primary btn-large">Start organizing for free</a>
            <div class="store-row">
              <a href="#download" class="store-logo-link" aria-label="Download on the App Store">
                <img class="store-logo-image" src="<?php echo esc_url( get_template_directory_uri() . '/assets/store/app-store-logo.svg' ); ?>" alt="" aria-hidden="true" />
              </a>
              <a href="#download" class="store-logo-link" aria-label="Get it on Google Play">
                <img class="store-logo-image" src="<?php echo esc_url( get_template_directory_uri() . '/assets/store/google-play-logo.svg' ); ?>" alt="" aria-hidden="true" />
              </a>
            </div>
          </div>
        </div>

        <div class="hero-visual reveal delay-1">
          <div class="hero-visual-watermark top-left" aria-hidden="true"></div>
          <div class="hero-visual-watermark top-right" aria-hidden="true"></div>
          <div class="hero-visual-watermark mid-right" aria-hidden="true"></div>
          <div class="hero-visual-watermark bottom-right" aria-hidden="true"></div>
          <img class="hero-phones-image" src="<?php echo esc_url( get_template_directory_uri() . '/assets/illustrations/hero-phones-en.png' ); ?>" alt="" />
        </div>
      </div>
    </section>

    <section class="section benefits" id="benefits">
      <div class="container section-title reveal">
        <h2>Shared childcare can be easier</h2>
      </div>
      <div class="container cards cards-3"><article class="soft-card benefit-card reveal">
          <div class="circle-icon blue-soft"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/icons/comments.svg' ); ?>" alt="" aria-hidden="true" /></div>
          <h3>Communication</h3>
          <p>Secure chat and a conversation archive to avoid misunderstandings.</p>
        </article><article class="soft-card benefit-card reveal delay-1">
          <div class="circle-icon green-soft"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/icons/calendar-days.svg' ); ?>" alt="" aria-hidden="true" /></div>
          <h3>Organization</h3>
          <p>A shared calendar and parenting schedule always within reach.</p>
        </article><article class="soft-card benefit-card reveal delay-2">
          <div class="circle-icon coral-soft"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/icons/wallet.svg' ); ?>" alt="" aria-hidden="true" /></div>
          <h3>Finances</h3>
          <p>Clear and transparent expense tracking related to your child.</p>
        </article></div>
    </section>

    <section class="section features" id="features">
      <div class="container section-title reveal">
        <h2>Everything you need<br />in one place</h2>
      </div>
      <div class="container feature-grid"><article class="feature-card reveal border-teal">
          <div class="feature-icon teal-bg"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/icons/calendar-check.svg' ); ?>" alt="" aria-hidden="true" /></div>
          <h3>Shared calendar</h3>
          <p>Plan appointments, holidays, school and events without scheduling conflicts.</p>
        </article><article class="feature-card reveal delay-1 border-blue">
          <div class="feature-icon blue-bg"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/icons/comment-dots.svg' ); ?>" alt="" aria-hidden="true" /></div>
          <h3>Secure chat</h3>
          <p>Talk only about your child in one organized place.</p>
        </article><article class="feature-card reveal delay-2 border-coral">
          <div class="feature-icon coral-bg"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/icons/receipt.svg' ); ?>" alt="" aria-hidden="true" /></div>
          <h3>Expense tracking</h3>
          <p>Add receipts and easily settle parenting-related costs.</p>
        </article><article class="feature-card reveal border-yellow">
          <div class="feature-icon yellow-bg"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/icons/folder-open.svg' ); ?>" alt="" aria-hidden="true" /></div>
          <h3>Child documents</h3>
          <p>Store important files, notes, certificates and check-up dates.</p>
        </article><article class="feature-card reveal delay-1 border-purple">
          <div class="feature-icon purple-bg"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/icons/house-user.svg' ); ?>" alt="" aria-hidden="true" /></div>
          <h3>Parenting schedule</h3>
          <p>Set up care routines and quickly check who is responsible each day.</p>
        </article><article class="feature-card reveal delay-2 border-teal">
          <div class="feature-icon teal-bg"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/icons/bell.svg' ); ?>" alt="" aria-hidden="true" /></div>
          <h3>Notifications</h3>
          <p>Get reminders about important events, payments and changes.</p>
        </article></div>
    </section>

    <section class="section how-it-works" id="how-it-works">
      <div class="container how-grid">
        <div class="how-copy reveal">
          <h2>How does Coparentes work?</h2>
          <div class="step-list"><article class="step-item">
              <span class="step-number teal-text">1</span>
              <div>
                <h3>Create an account and invite the other parent</h3>
                <p>A quick start and a transparent beginning to your cooperation.</p>
              </div>
            </article><article class="step-item">
              <span class="step-number blue-text">2</span>
              <div>
                <h3>Set up your child’s profile</h3>
                <p>Add the child’s details, schedule and most important information.</p>
              </div>
            </article><article class="step-item">
              <span class="step-number coral-text">3</span>
              <div>
                <h3>Use the organization tools</h3>
                <p>Chat, calendar, expenses and documents work together.</p>
              </div>
            </article><article class="step-item">
              <span class="step-number yellow-text">4</span>
              <div>
                <h3>Enjoy calmer parenting</h3>
                <p>Less chaos, more clarity and better cooperation for your child’s wellbeing.</p>
              </div>
            </article></div>
        </div>

        <div class="how-visual reveal delay-1">
          <img class="how-phone-image" src="<?php echo esc_url( get_template_directory_uri() . '/assets/illustrations/how-it-works-phone-pl.png' ); ?>" alt="" />
          <div class="family-card">
            <div class="family-avatars"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/illustrations/family-avatars.svg' ); ?>" alt="" aria-hidden="true" /></div>
            <p>It’s easier to cooperate when everything is in one place.</p>
          </div>
        </div>
      </div>
    </section>

    <section class="section follow-up" id="follow-up">
      <div class="container follow-up-grid">
        <div class="follow-up-copy reveal">
          <span class="eyebrow">Follow-up</span>
          <h2>Never lose the next step</h2>
          <p>After a conversation, calendar change, or new expense, Coparentes helps turn agreements into concrete actions.</p>
        </div>
        <div class="follow-up-list">
          <article class="follow-up-card reveal delay-1">
            <div class="feature-icon blue-bg"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/icons/comment-dots.svg' ); ?>" alt="" aria-hidden="true" /></div>
            <div>
              <h3>Conversation follow-ups</h3>
              <p>Flag a message as a task and return to it when a decision or reply is needed.</p>
            </div>
          </article>
          <article class="follow-up-card reveal delay-2">
            <div class="feature-icon teal-bg"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/icons/calendar-check.svg' ); ?>" alt="" aria-hidden="true" /></div>
            <div>
              <h3>Deadline reminders</h3>
              <p>Add a follow-up for pickups, appointments, or payments so both parents know what is next.</p>
            </div>
          </article>
          <article class="follow-up-card reveal delay-1">
            <div class="feature-icon coral-bg"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/icons/bell.svg' ); ?>" alt="" aria-hidden="true" /></div>
            <div>
              <h3>Calm closure</h3>
              <p>Mark tasks as done to avoid extra questions and misunderstandings.</p>
            </div>
          </article>
        </div>
      </div>
    </section>

    <section class="section audience" id="audience">
      <div class="container section-title reveal">
        <h2>Who is Coparentes for?</h2>
      </div>
      <div class="container cards cards-4"><article class="soft-card audience-card reveal">
          <img class="house-illustration" src="<?php echo esc_url( get_template_directory_uri() . '/assets/illustrations/audience-mom.svg' ); ?>" alt="" aria-hidden="true" />
          <h3>For mom</h3>
          <p>Stay calm and keep control of your child’s schedule.</p>
        </article><article class="soft-card audience-card reveal delay-1">
          <img class="house-illustration" src="<?php echo esc_url( get_template_directory_uri() . '/assets/illustrations/audience-dad.svg' ); ?>" alt="" aria-hidden="true" />
          <h3>For dad</h3>
          <p>Always stay up to date with your child’s life.</p>
        </article><article class="soft-card audience-card reveal delay-2">
          <img class="house-illustration" src="<?php echo esc_url( get_template_directory_uri() . '/assets/illustrations/audience-child.svg' ); ?>" alt="" aria-hidden="true" />
          <h3>For the child</h3>
          <p>More predictability means more peace.</p>
        </article><article class="soft-card audience-card reveal delay-3">
          <img class="house-illustration" src="<?php echo esc_url( get_template_directory_uri() . '/assets/illustrations/audience-family.svg' ); ?>" alt="" aria-hidden="true" />
          <h3>For the whole family</h3>
          <p>Shared organization for the benefit of the child.</p>
        </article></div>
    </section>

    <section class="section testimonials" id="testimonials">
      <div class="container section-title reveal">
        <h2>What do parents say?</h2>
      </div>
      <div class="container cards cards-3"><article class="soft-card testimonial-card reveal">
          <img class="person-avatar" src="<?php echo esc_url( get_template_directory_uri() . '/assets/illustrations/avatar-anna.svg' ); ?>" alt="Ewa" />
          <div class="stars"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/icons/stars-rating.svg' ); ?>" alt="5/5" /></div>
          <blockquote>“My life would have been easier if an app like this had existed during my divorce.”</blockquote>
          <p class="person-name">Ewa</p>
        </article><article class="soft-card testimonial-card reveal delay-1">
          <img class="person-avatar" src="<?php echo esc_url( get_template_directory_uri() . '/assets/illustrations/avatar-marek.svg' ); ?>" alt="Andrzej" />
          <div class="stars"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/icons/stars-rating.svg' ); ?>" alt="5/5" /></div>
          <blockquote>“I don’t like running many apps, but I’m happy to try this one because I feel it could really make my life easier.”</blockquote>
          <p class="person-name">Andrzej</p>
        </article><article class="soft-card testimonial-card reveal delay-2">
          <img class="person-avatar" src="<?php echo esc_url( get_template_directory_uri() . '/assets/illustrations/avatar-kasia.svg' ); ?>" alt="Agnieszka" />
          <div class="stars"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/icons/stars-rating.svg' ); ?>" alt="5/5" /></div>
          <blockquote>“I’m convinced that thanks to Coparentes it will be easier for me to document expenses for my children.”</blockquote>
          <p class="person-name">Agnieszka</p>
        </article></div>
    </section>

    <section class="cta-section" id="download">
      <div class="cta-watermark left" aria-hidden="true"></div>
      <div class="cta-watermark right" aria-hidden="true"></div>
      <div class="container cta-content reveal">
        <h2>Start organizing<br />life more calmly</h2>
        <a href="#" class="btn btn-white btn-large">Download for free</a>
        <div class="store-row center cta-store-row">
          <a href="#" class="store-badge light" aria-label="App Store">
            <img class="store-badge-icon" src="<?php echo esc_url( get_template_directory_uri() . '/assets/icons/apple.svg' ); ?>" alt="" aria-hidden="true" />
            <span><small>Download on</small><strong>App Store</strong></span>
          </a>
          <a href="#" class="store-badge light" aria-label="Google Play">
            <img class="store-badge-icon" src="<?php echo esc_url( get_template_directory_uri() . '/assets/icons/google-play.svg' ); ?>" alt="" aria-hidden="true" />
            <span><small>Get it on</small><strong>Google Play</strong></span>
          </a>
        </div>
        <p>Free. No commitment.</p>
      </div>
    </section>
